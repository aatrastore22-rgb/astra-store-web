# Guía de Despliegue: Supabase + Netlify — Astra Store

Esta guía te permite alojar la tienda y portales en **Netlify** con dominio HTTPS gratis y gestionar usuarios, pedidos y saldo en **Supabase**.

---

## Paso 1: Configurar Supabase (Base de Datos)

1. Entra a [supabase.com](https://supabase.com) y crea un nuevo proyecto (ejemplo: `astra-store-db`).
2. En el menú lateral izquierdo, ve a **SQL Editor** y haz clic en **New query**.
3. Pega este código SQL y dale al botón **Run**:

```sql
-- 1. Tabla de Revendedores Autorizados
create table revendedores (
  id uuid primary key default gen_random_uuid(),
  codigo text unique not null,
  nombre text not null,
  email text unique not null,
  saldo_ars numeric(12,2) default 0.00,
  estado text default 'activo',
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 2. Tabla de Pedidos Despachados
create table pedidos (
  id uuid primary key default gen_random_uuid(),
  tipo_usuario text not null,
  revendedor_id uuid references revendedores(id),
  player_id text not null,
  producto text not null,
  monto_ars numeric(12,2) not null,
  pasarela text default 'chytapay',
  estado text default 'completado',
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 3. Tabla de Recargas de Saldo
create table recargas_saldo (
  id uuid primary key default gen_random_uuid(),
  revendedor_id uuid references revendedores(id) not null,
  monto_ars numeric(12,2) not null,
  metodo text not null,
  comprobante_url text,
  estado text default 'pendiente',
  created_at timestamp with time zone default timezone('utc'::text, now())
);
```

4. Ve a **Project Settings > API** y copia:
   - **Project URL**
   - **service_role key** (clave secreta para que la función de Netlify actualice saldos)

---

## Paso 2: Subir a Netlify

1. Entra a [netlify.com](https://netlify.com) e inicia sesión.
2. Arrastra la carpeta de este proyecto (o conéctalo a tu repositorio de GitHub).
3. Netlify detectará automáticamente el archivo `netlify.toml` que ya dejé configurado.
4. En Netlify, ve a **Site configuration > Environment variables** y agrega:

| Variable | Valor |
| :--- | :--- |
| `CHYTAPAY_PUBLIC_KEY` | `pk_live_9fffcfcd5ca09b634c075b2cb918178e` |
| `CHYTAPAY_CLIENT_SECRET` | `1nljremsbomqbl1fi3m19a146pkf9ttfchugafs8fa72rg5k1ein` |
| `CHYTAPAY_WEBHOOK_SECRET` | `whsec_264a0c61327f27059af5981170c25f9015127411b29de5a7b2fb0eaf4a1d0ecf` |
| `DIAMONDS_API_KEY` | `co_live_RqL1ICi6pWpry8HSyxI6g1zg1hf_Tnz2YedS1VPHupw` |
| `DIAMONDS_API_URL` | `https://portal.centraloneglobal.com/api/v1` |
| `BOOYAH_API_KEY` | `9fInnLO9eiDASHs31XzIlYHeGXFaIV4vplAYp2bj0SnCQJod` |
| `BOOYAH_API_URL` | `https://lojaff.com/api/v1` |
| `SUPABASE_URL` | `https://tu-proyecto.supabase.co` |
| `SUPABASE_SERVICE_ROLE_KEY` | `tu_clave_service_role` |

---

## Paso 3: Conectar el Webhook en Chytapay

Una vez desplegado en Netlify, tendrás tu dominio (por ejemplo `https://astra-store.netlify.app`):
1. Ve a tu panel de **Chytapay > Webhooks**.
2. Registra esta URL:
   `https://tu-sitio.netlify.app/webhook/chytapay`
3. ¡Listo! Cada pago de cliente o revendedor disparará la función serverless de Netlify que entrega los diamantes/pases y actualiza el saldo en Supabase automáticamente.
