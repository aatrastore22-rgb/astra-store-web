---
name: "Astra Store"
description: "High-performance automated Free Fire top-up and authorized reseller management system."
---

## Overview

Astra Store is a mission-critical automated digital distribution platform designed exclusively for Free Fire top-ups (6 diamond packages + Booyah Pass) serving direct consumers and wholesale authorized resellers. All upstream supplier connections and provider routing remain completely white-labeled and private to the administrator. The visual style is dark-mode centric, high-contrast, modern gaming fintech with crisp borders, precise tabular metrics, and unambiguous transactional states.

- **Audience:** Platform administrators handling payment gateway reconciliations, manual proof validations, and automated API top-up dispatches.
- **Brand Personality:** Crisp, reliable, instantaneous, and gamer-attuned with deep obsidian tones and blazing energetic amber-orange accents.

## Colors

The palette leverages an obsidian deep dark canvas with vibrant flame-orange as the primary brand action, paired with cyan-teal for automated balance signals, emerald for authorized success, and amber for pending verification.

- **Primary:** Blazing flame orange representing speed and gaming excitement.
- **Secondary:** Cyber cyan for automated balance and system status.
- **Accent:** Vibrant gold amber for diamond currency and VIP tier highlights.

```yaml
colors:
  accent: "#F59E0B"
  success: "#10B981"
  warning: "#F59E0B"
  error: "#EF4444"
  info: "#06B6D4"
  light:
    primary: "#C2410C"
    on-primary: "#FFFFFF"
    surface: "#FFFFFF"
    on-surface: "#0F172A"
    surface-variant: "#F1F5F9"
    on-surface-variant: "#334155"
    outline: "#CBD5E1"
  dark:
    primary: "#F97316"
    on-primary: "#0C0A09"
    surface: "#090A0F"
    on-surface: "#F8FAFC"
    surface-variant: "#131722"
    on-surface-variant: "#94A3B8"
    outline: "#1E293B"
```

## Typography

The type system pairs **Plus Jakarta Sans** for crisp, geometric headers with **Instrument Sans** for dense, readable tabular data, complemented by **Red Hat Mono** for player PlayerIDs, transaction hashes, and diamond counts.

```yaml
typography:
  display-lg:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 40px
    fontWeight: 700
    lineHeight: 48px
    letterSpacing: -0.5px
  display-lg-mobile:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 30px
    fontWeight: 700
    lineHeight: 38px
    letterSpacing: -0.25px
  headline-lg:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 28px
    fontWeight: 700
    lineHeight: 34px
    letterSpacing: -0.25px
  headline-lg-mobile:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 22px
    fontWeight: 700
    lineHeight: 28px
    letterSpacing: -0.2px
  headline-md:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 20px
    fontWeight: 600
    lineHeight: 26px
  title-lg:
    fontFamily: "Plus Jakarta Sans"
    fontSize: 18px
    fontWeight: 600
    lineHeight: 24px
  title-md:
    fontFamily: "Instrument Sans"
    fontSize: 16px
    fontWeight: 600
    lineHeight: 22px
  body-lg:
    fontFamily: "Instrument Sans"
    fontSize: 16px
    fontWeight: 400
    lineHeight: 24px
  body-md:
    fontFamily: "Instrument Sans"
    fontSize: 14px
    fontWeight: 400
    lineHeight: 20px
  body-sm:
    fontFamily: "Instrument Sans"
    fontSize: 12px
    fontWeight: 400
    lineHeight: 16px
  label-lg:
    fontFamily: "Instrument Sans"
    fontSize: 14px
    fontWeight: 600
    lineHeight: 20px
  label-md:
    fontFamily: "Instrument Sans"
    fontSize: 12px
    fontWeight: 600
    lineHeight: 16px
  label-sm:
    fontFamily: "Instrument Sans"
    fontSize: 11px
    fontWeight: 600
    lineHeight: 14px
  mono-sm:
    fontFamily: "Red Hat Mono"
    fontSize: 12px
    fontWeight: 500
    lineHeight: 16px
  mono-md:
    fontFamily: "Red Hat Mono"
    fontSize: 14px
    fontWeight: 500
    lineHeight: 20px
```

## Layout & Spacing

Fluid desktop grid with fixed sidebar navigation (250px) and a main content work area with 24px internal container padding. The spacing scale is built on a 4px and 8px rhythm.

```yaml
spacing:
  gutter-xs: 4px
  gutter-sm: 8px
  gutter-md: 16px
  gutter-lg: 24px
  gutter-xl: 32px
  section: 40px
  page-margin: 24px
```

## Elevation & Depth

Deep dark theme styling relies on surface-variant container borders (`#1E293B`) and subtle inner glows rather than heavy drop shadows. High contrast text ensures instant visibility in fast-paced operational shifts.

## Shapes

Clean, modern ergonomic corners. Rounded containers with sharp inner elements for a technical, tactical aesthetic.

```yaml
rounded:
  sm: 4px
  DEFAULT: 8px
  md: 10px
  lg: 14px
  xl: 18px
  full: 9999px
```

## Motion & Micro-interaction

Micro-interactions are snappy and informative. Approval actions trigger immediate color state shifts and badge transitions without distracting layout shifting.

```yaml
motion:
  state-change:
    duration: 120ms
    delay: 0ms
    timingFunction: ease-out
  surface-enter:
    duration: 200ms
    delay: 0ms
    timingFunction: cubic-bezier(0.16, 1, 0.3, 1)
  surface-exit:
    duration: 150ms
    delay: 0ms
    timingFunction: cubic-bezier(0.4, 0, 1, 1)
```

## Voice & Content Strategy

Direct, operational, and actionable. Terminology is standard gaming distribution nomenclature: "Player ID", "Recarga Directa (Garena API)", "Saldo Mayorista", "Comprobante de Depósito", and "Pase Booyah". Actions are affirmative and explicit: "Aprobar Saldo", "Rechazar Solicitud", "Reintentar Despacho API".

## Components

Component implementations live as individual HTML sticker sheet files in
`components/`. Each file contains the canonical, styled HTML components with
`<!-- COMPONENT: name -->` comment markers. Read each file before use.

- **Badge** → `@components/badge.html`: `badge-numeric`, `badge-dot`
- **Button** → `@components/button.html`: `button-primary`, `button-icon`, `button-with-icon`
- **Card** → `@components/card.html`: `card-elevated`, `card-action`, `card-interactive`, `card-interactive-2`
- **Modal** → `@components/modal.html`: `modal-standard`, `modal-alert`, `modal-drawer`
- **Table** → `@components/table.html`: `table-standard`, `table-interactive`, `table-selectable`
